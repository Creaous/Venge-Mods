(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/vkaparthi/lab/request-interceptor/src/main.ts */"zUnb");


/***/ }),

/***/ "6oBl":
/*!*************************************************************!*\
  !*** ./src/app/components/edit-rule/edit-rule.component.ts ***!
  \*************************************************************/
/*! exports provided: EditRuleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRuleComponent", function() { return EditRuleComponent; });
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store/actions */ "K9il");
/* harmony import */ var _models_action_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../models/action-types */ "dRsL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _services_data_model_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/data-model.service */ "wfsL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-select/ng-select */ "ZOsW");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _toggle_toggle_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../toggle/toggle.component */ "7FIb");










function EditRuleComponent_sl_tooltip_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "sl-tooltip", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function EditRuleComponent_app_toggle_34_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "app-toggle", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function EditRuleComponent_app_toggle_34_Template_app_toggle_change_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); ctx_r5.rule.enabled = $event; return ctx_r5.onRulePropertyChange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", ctx_r1.rule.enabled);
} }
function EditRuleComponent_div_35_sl_tooltip_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "sl-tooltip", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function EditRuleComponent_div_35_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "label", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2, " Description ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, EditRuleComponent_div_35_sl_tooltip_3_Template, 2, 0, "sl-tooltip", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "input", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_div_35_Template_input_ngModelChange_6_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r8.rule.description = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r2.showInfo);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx_r2.rule.description);
} }
function EditRuleComponent_sl_tooltip_39_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "sl-tooltip", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "i", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function EditRuleComponent_tr_43_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "input", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_4_Template_input_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r21); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.name = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "input", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_4_Template_input_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r21); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.value = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.value);
} }
function EditRuleComponent_tr_43_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "input", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_5_Template_input_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r27); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.name = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.name);
} }
function EditRuleComponent_tr_43_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "input", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_6_Template_input_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.name = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "input", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_6_Template_input_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.value = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.value);
} }
function EditRuleComponent_tr_43_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "td", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
function EditRuleComponent_tr_43_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "input", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_8_Template_input_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r37); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.value = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.value);
} }
function EditRuleComponent_tr_43_ng_container_9_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_ng_container_9_Template_input_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r41); const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; return action_r10.details.value = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", action_r10.details.value);
} }
function EditRuleComponent_tr_43_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "td", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} }
function EditRuleComponent_tr_43_Template(rf, ctx) { if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "ng-select", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_tr_43_Template_ng_select_ngModelChange_2_listener($event) { const action_r10 = ctx.$implicit; return action_r10.type = $event; })("change", function EditRuleComponent_tr_43_Template_ng_select_change_2_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r45); const action_r10 = restoredCtx.$implicit; const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r44.onActionTypeChange(action_r10); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](3, 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, EditRuleComponent_tr_43_ng_container_4_Template, 5, 2, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, EditRuleComponent_tr_43_ng_container_5_Template, 3, 1, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](6, EditRuleComponent_tr_43_ng_container_6_Template, 5, 2, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, EditRuleComponent_tr_43_ng_container_7_Template, 2, 0, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](8, EditRuleComponent_tr_43_ng_container_8_Template, 3, 1, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](9, EditRuleComponent_tr_43_ng_container_9_Template, 3, 1, "ng-container", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, EditRuleComponent_tr_43_ng_container_10_Template, 2, 0, "ng-container", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "td", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "sl-tooltip", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "i", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function EditRuleComponent_tr_43_Template_i_click_13_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r45); const action_r10 = restoredCtx.$implicit; const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r46.deleteRuleAction(action_r10, ctx_r46.rule); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const action_r10 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("items", ctx_r4.allActionTypes)("ngModel", action_r10.type)("clearable", false)("searchable", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitch", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", ctx_r4.isAddModifyHeader(action_r10.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", ctx_r4.isDeleteHeaderOrParam(action_r10.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", ctx_r4.isAddModifyQueryParam(action_r10.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", action_r10.type === ctx_r4.actionTypesEnum.BLOCK_REQUEST);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", action_r10.type === ctx_r4.actionTypesEnum.REDIRECT_TO);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngSwitchCase", action_r10.type === ctx_r4.actionTypesEnum.THROTTLE);
} }
const Add_Modify_Header_Set = new Set([
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].ADD_REQUEST_HEADER,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].MODIFY_REQUEST_HEADER,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].ADD_RESPONSE_HEADER,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].MODIFY_RESPONSE_HEADER
]);
const Delete_Header_Or_Param_Set = new Set([
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].DELETE_REQUEST_HEADER,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].DELETE_RESPONSE_HEADER,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].DELETE_QUERY_PARAM
]);
const Add_Modify_Query_Param_Set = new Set([
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].ADD_QUERY_PARAM,
    _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"].MODIFY_QUERY_PARAM
]);
class EditRuleComponent {
    constructor(modalService, dataModalService, cdr, store) {
        this.modalService = modalService;
        this.dataModalService = dataModalService;
        this.cdr = cdr;
        this.store = store;
        this.actionTypesEnum = _models_action_types__WEBPACK_IMPORTED_MODULE_1__["ActionTypesEnum"];
    }
    ngOnInit() {
        this.allActionTypes = this.dataModalService.getActions();
    }
    detectChanges() {
        this.cdr.detectChanges();
    }
    deleteRule(rule, ruleGroup) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].deleteRule({ rule, ruleGroup }));
    }
    addRuleAction(rule) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].addRuleAction({ rule }));
    }
    deleteRuleAction(action, rule) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].deleteRuleAction({ action, rule }));
    }
    onRulePropertyChange() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].onChange());
    }
    onActionTypeChange(action) {
        action.details = {};
        this.detectChanges();
    }
    isAddModifyHeader(type) {
        return Add_Modify_Header_Set.has(type);
    }
    isDeleteHeaderOrParam(type) {
        return Delete_Header_Or_Param_Set.has(type);
    }
    isAddModifyQueryParam(type) {
        return Add_Modify_Query_Param_Set.has(type);
    }
    getMessage(actions = []) {
        if (actions.some(action => action.type === 'block-request')) {
            let suffix = '';
            if (actions.length > 1) {
                suffix = ', all other actions will be ignored';
            }
            return 'Requests matching this rule will be blocked' + suffix;
        }
        if (actions.some(action => action.type === 'redirect-to')) {
            return 'Requests matching this rule will be redirected';
        }
    }
}
EditRuleComponent.ɵfac = function EditRuleComponent_Factory(t) { return new (t || EditRuleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_data_model_service__WEBPACK_IMPORTED_MODULE_4__["DataModelService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"])); };
EditRuleComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: EditRuleComponent, selectors: [["app-edit-rule"]], inputs: { rule: "rule", ruleGroup: "ruleGroup", showInfo: "showInfo", uiSettings: "uiSettings" }, decls: 46, vars: 13, consts: [[1, "list-group-item-container", "p-3", "mb-3", "bg-white", "rounded"], [1, "d-flex", "align-items-center"], [1, "w-130"], ["content", "rule condition", "placement", "right", 4, "ngIf"], [1, "d-flex", "flex-fill", "flex-grow-1"], [1, "w-130", "form-control", "border-right-0", "p-0"], [1, "custom-ng-select", 3, "ngModel", "clearable", "searchable", "ngModelChange"], ["value", "url"], [1, "w-130", "form-control", "p-0", "border-right-0"], ["value", "starts-with"], ["value", "equals"], ["value", "contains"], ["value", "regex"], [1, "col-6", "p-0"], [1, "form-control", 3, "ngModel", "ngModelChange"], [1, "d-flex", "align-items-end", "ml-auto", "rule-btn-actions"], ["content", "delete this rule", "placement", "left"], [1, "btn", "btn-sm", "text-danger", 3, "click"], [1, "fa", "fa-trash"], ["content", "add a new action to this rule", "placement", "left"], [1, "btn", "btn-sm", "text-primary", 3, "click"], [1, "fa", "fa-plus"], ["content", "enable/disable rule", "placement", "left"], ["class", "small rule-enable-toggle", 3, "value", "change", 4, "ngIf"], ["class", "d-flex align-items-center mt-3", 4, "ngIf"], [1, "d-flex", "align-items-center", "mt-3", "rule-actions"], ["content", "actions to perform when rule condition is met", "placement", "right", 4, "ngIf"], [1, "flex-grow-1"], [1, "table", "table-bordered", "table-sm", "actions-table"], [4, "ngFor", "ngForOf"], [1, "text-warning", "text-right"], ["content", "rule condition", "placement", "right"], [1, "fa", "fa-info-circle", "ml-1"], [1, "small", "rule-enable-toggle", 3, "value", "change"], [1, "d-flex", "align-items-center", "mt-3"], ["content", "rule description", "placement", "right", 4, "ngIf"], [1, "p-0", "rule-description"], ["placeholder", "description", 1, "form-control", 3, "ngModel", "ngModelChange"], ["content", "rule description", "placement", "right"], ["content", "actions to perform when rule condition is met", "placement", "right"], [1, "w-260"], ["bindValue", "key", 1, "custom-ng-select", 3, "items", "ngModel", "clearable", "searchable", "ngModelChange", "change"], [3, "ngSwitch"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"], [1, "text-center", "align-middle", "w-50-important"], ["content", "delete this action", "placement", "left"], [1, "fa", "fa-times", "cursor-pointer", 3, "click"], ["placeholder", "Name", 1, "form-control", 3, "ngModel", "ngModelChange"], ["placeholder", "Value", 1, "form-control", 3, "ngModel", "ngModelChange"], ["colspan", "2"], ["colspan", "2", 1, "disabled-td"], ["placeholder", "Redirection URL", 1, "form-control", 3, "ngModel", "ngModelChange"], ["placeholder", "Delay amount in ms", 1, "form-control", 3, "ngModel", "ngModelChange"]], template: function EditRuleComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3, " When Request's ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, EditRuleComponent_sl_tooltip_4_Template, 2, 0, "sl-tooltip", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ng-select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_Template_ng_select_ngModelChange_7_listener($event) { return ctx.rule.criteria.key = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ng-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, "URL");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ng-select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_Template_ng_select_ngModelChange_11_listener($event) { return ctx.rule.criteria.condition = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "ng-option", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13, "StartsWith");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "ng-option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, "Equals");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "ng-option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "Contains");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "ng-option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "Matches(RegEx)");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function EditRuleComponent_Template_input_ngModelChange_21_listener($event) { return ctx.rule.criteria.value = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "sl-tooltip", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function EditRuleComponent_Template_button_click_24_listener() { return ctx.deleteRule(ctx.rule, ctx.ruleGroup); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](25, "i", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](27, "Delete");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "sl-tooltip", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function EditRuleComponent_Template_button_click_29_listener() { return ctx.addRuleAction(ctx.rule); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](30, "i", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](32, "Add Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "sl-tooltip", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](34, EditRuleComponent_app_toggle_34_Template, 1, 1, "app-toggle", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](35, EditRuleComponent_div_35_Template, 7, 2, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](38, " Actions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](39, EditRuleComponent_sl_tooltip_39_Template, 2, 0, "sl-tooltip", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "table", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](42, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](43, EditRuleComponent_tr_43_Template, 14, 11, "tr", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showInfo);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.rule.criteria.key)("clearable", false)("searchable", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.rule.criteria.condition)("clearable", false)("searchable", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngModel", ctx.rule.criteria.value);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.uiSettings.allowRuleEnableDisable);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.uiSettings.showRuleDescription);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showInfo);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.rule.actions);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.getMessage(ctx.rule.actions));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__["NgSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgModel"], _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__["ɵr"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["DefaultValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], _toggle_toggle_component__WEBPACK_IMPORTED_MODULE_9__["ToggleComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgSwitchCase"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgSwitchDefault"]], styles: [".list-group-item-container[_ngcontent-%COMP%] {\n  border: 1px solid #eee;\n  box-shadow: 0 5px 11px 0 rgba(0, 0, 0, 0.12), 0 4px 15px 0 rgba(0, 0, 0, 0.1) !important;\n}\n\n.rule-actions[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  border-left: none;\n  border-top: none;\n  border-bottom: none;\n  border-right: none;\n  width: 100%;\n}\n\n.w-130[_ngcontent-%COMP%] {\n  width: 130px;\n}\n\n.w-50-important[_ngcontent-%COMP%] {\n  width: 50px !important;\n}\n\n.w-50[_ngcontent-%COMP%] {\n  width: 50px;\n}\n\n.w-130[_ngcontent-%COMP%] {\n  width: 130px;\n}\n\n.w-260[_ngcontent-%COMP%] {\n  width: 260px;\n}\n\n.f-s-20[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\n\nselect.form-control[_ngcontent-%COMP%] {\n  width: 130px;\n}\n\n.form-control[_ngcontent-%COMP%]:focus {\n  box-shadow: none;\n}\n\n.form-control[_ngcontent-%COMP%], .form-group[_ngcontent-%COMP%]    > label[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n\n.disabled-td[_ngcontent-%COMP%] {\n  background: #eeeeee;\n  opacity: 0.3;\n}\n\n.actions-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 0 !important;\n  border-color: #ccc !important;\n}\n\n.rule-description[_ngcontent-%COMP%] {\n  width: calc(50% + 260px);\n}\n\n.rule-enable-toggle[_ngcontent-%COMP%] {\n  position: relative;\n  top: -4px;\n}"] });


/***/ }),

/***/ "7BWJ":
/*!**************************************!*\
  !*** ./src/app/models/rule-group.ts ***!
  \**************************************/
/*! exports provided: RuleGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleGroup", function() { return RuleGroup; });
/* harmony import */ var _rule_group_filter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rule-group-filter */ "8wNY");
/* harmony import */ var _rule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rule */ "shEE");
/* harmony import */ var _util_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/utils */ "Gndo");



const ruleGroupNameGen = Object(_util_utils__WEBPACK_IMPORTED_MODULE_2__["UniqNameGen"])('Rule Group');
class RuleGroup {
    constructor(id = Object(_util_utils__WEBPACK_IMPORTED_MODULE_2__["uuid"])(), name = ruleGroupNameGen.next().value) {
        this.enabled = true;
        this.id = id;
        this.name = name;
        this.filter = new _rule_group_filter__WEBPACK_IMPORTED_MODULE_0__["RuleGroupFilter"]('page-url', 'starts-with', '');
        this.rules = [
            new _rule__WEBPACK_IMPORTED_MODULE_1__["Rule"]()
        ];
    }
    static create(data = {}) {
        const instance = new RuleGroup(data.id, data.name);
        instance.description = data.description;
        instance.enabled = data.enabled;
        instance.filter = _rule_group_filter__WEBPACK_IMPORTED_MODULE_0__["RuleGroupFilter"].create(data.filter);
        instance.rules = (data.rules || []).map(rule => _rule__WEBPACK_IMPORTED_MODULE_1__["Rule"].create(rule));
        return instance;
    }
}


/***/ }),

/***/ "7FIb":
/*!*******************************************************!*\
  !*** ./src/app/components/toggle/toggle.component.ts ***!
  \*******************************************************/
/*! exports provided: ToggleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToggleComponent", function() { return ToggleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");


class ToggleComponent {
    constructor() {
        this.value = false;
        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onText = 'On';
        this.offText = 'Off';
    }
    onChange($event) {
        this.change.emit($event);
    }
    handleClick() {
        this.value = !this.value;
        this.change.emit(this.value);
    }
}
ToggleComponent.ɵfac = function ToggleComponent_Factory(t) { return new (t || ToggleComponent)(); };
ToggleComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ToggleComponent, selectors: [["app-toggle"]], inputs: { value: "value", onText: "onText", offText: "offText" }, outputs: { change: "change" }, decls: 8, vars: 6, consts: [[1, "ng-toggle", "ng-toggle-animate", "btn", "btn-sm", 3, "click"], [1, "ng-toggle-container"], [1, "btn", "btn-primary", "ng-toggle-on", "btn-sm"], [1, "ng-toggle-handle", "btn", "btn-sm", "btn-light"], [1, "btn", "btn-danger", "ng-toggle-off", "btn-sm"]], template: function ToggleComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ToggleComponent_Template_div_click_0_listener() { return ctx.handleClick(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "\u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("off", !ctx.value)("on", ctx.value);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.onText, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.offText, " ");
    } }, styles: [".large[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%], .medium[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%], .small[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 28px;\n}\n.large[_nghost-%COMP%]   .ng-toggle.off[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%], .medium[_nghost-%COMP%]   .ng-toggle.off[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%], .small[_nghost-%COMP%]   .ng-toggle.off[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%] {\n  margin-left: -35px;\n}\n.large[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%], .medium[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%], .small[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%] {\n  width: 83px;\n}\n.large[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .large[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%], .medium[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .medium[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%], .small[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .small[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%] {\n  width: 35px;\n}\n.medium[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%] {\n  height: 24px;\n}\n.small[_nghost-%COMP%]   .ng-toggle[_ngcontent-%COMP%] {\n  height: 20px;\n}\n.ng-toggle[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  cursor: pointer;\n  overflow: hidden;\n  padding: 0 !important;\n  text-align: left;\n  z-index: 0;\n  user-select: none;\n  vertical-align: middle;\n  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;\n  box-sizing: content-box;\n  width: 100%;\n}\n.ng-toggle.disabled[_ngcontent-%COMP%], .ng-toggle.disabled[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  cursor: default;\n  pointer-events: none;\n}\n.ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-handle[_ngcontent-%COMP%] {\n  display: flex !important;\n}\n.ng-toggle[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%] {\n  align-items: stretch !important;\n  top: 0;\n  border-radius: 0;\n  transform: translateZ(0);\n}\n.ng-toggle.ng-toggle-animate[_ngcontent-%COMP%]   .ng-toggle-container[_ngcontent-%COMP%] {\n  transition: margin-left 0.5s;\n}\n.ng-toggle[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%] {\n  align-items: center !important;\n  text-align: center;\n  z-index: 1;\n  border-radius: 0;\n}\n.ng-toggle[_ngcontent-%COMP%]   .ng-toggle-on[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-off[_ngcontent-%COMP%], .ng-toggle[_ngcontent-%COMP%]   .ng-toggle-handle[_ngcontent-%COMP%] {\n  box-sizing: border-box;\n  cursor: pointer;\n  user-select: none;\n}\n.ng-toggle[_ngcontent-%COMP%]   .ng-toggle-handle[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: -2px;\n  margin-bottom: -2px;\n  z-index: 100;\n  width: 13px;\n  padding-left: 0;\n  padding-right: 0;\n  align-self: stretch !important;\n}\n.ng-toggle[_ngcontent-%COMP%]    > span[_ngcontent-%COMP%] {\n  height: 100%;\n}"] });


/***/ }),

/***/ "8wNY":
/*!*********************************************!*\
  !*** ./src/app/models/rule-group-filter.ts ***!
  \*********************************************/
/*! exports provided: RuleGroupFilter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleGroupFilter", function() { return RuleGroupFilter; });
class RuleGroupFilter {
    constructor(key, condition, value) {
        this.key = key;
        this.condition = condition;
        this.value = value;
    }
    static create(data = {}) {
        return new RuleGroupFilter(data.key, data.condition, data.value);
    }
}


/***/ }),

/***/ "9s53":
/*!**********************************!*\
  !*** ./src/app/store/reducer.ts ***!
  \**********************************/
/*! exports provided: initialState, reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./actions */ "K9il");
/* harmony import */ var _models_rule_group__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/rule-group */ "7BWJ");
/* harmony import */ var _models_rule__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/rule */ "shEE");
/* harmony import */ var _models_rule_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/rule-action */ "wsZ2");





const initialState = {
    uiSettings: {
        isExtensionEnabled: false,
        allowRuleEnableDisable: true,
        autoSave: false,
        showRuleDescription: false,
    },
    ruleGroups: [],
    loading: false,
    activeRuleGroupId: null,
};
const replaceAt = (arr, indexMatch, value) => {
    const index = arr.indexOf(indexMatch);
    return [
        ...arr.slice(0, index),
        Object.assign({}, value),
        ...arr.slice(index + 1),
    ];
};
const _reducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(initialState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].hasUnsavedChanges, (state, { flag }) => {
    return Object.assign(Object.assign({}, state), { hasUnsavedChanges: flag });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].fetchDataSet, _actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].saveDataSet, (state) => {
    return Object.assign(Object.assign({}, state), { loading: true });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].fetchDataSetSuccess, (state, { data }) => {
    var _a, _b, _c;
    const activeRuleGroupId = (_a = state === null || state === void 0 ? void 0 : state.activeRuleGroupId) !== null && _a !== void 0 ? _a : (_c = (_b = data === null || data === void 0 ? void 0 : data.ruleGroups) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.id;
    return Object.assign(Object.assign({}, state), { uiSettings: Object.assign(Object.assign({}, state.uiSettings), data.uiSettings), ruleGroups: [
            ...data.ruleGroups,
        ], loading: false, hasUnsavedChanges: false, activeRuleGroupId: activeRuleGroupId });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].enableExtension, (state) => {
    return Object.assign(Object.assign({}, state), { uiSettings: Object.assign(Object.assign({}, state.uiSettings), { isExtensionEnabled: true }) });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].disableExtension, (state) => {
    return Object.assign(Object.assign({}, state), { uiSettings: Object.assign(Object.assign({}, state.uiSettings), { isExtensionEnabled: false }) });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].addRuleGroup, (state) => {
    const _rg = new _models_rule_group__WEBPACK_IMPORTED_MODULE_2__["RuleGroup"]();
    return Object.assign(Object.assign({}, state), { ruleGroups: [
            ...state.ruleGroups,
            _rg,
        ], activeRuleGroupId: _rg.id });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].deleteRuleGroup, (state, { ruleGroup }) => {
    var _a, _b;
    return Object.assign(Object.assign({}, state), { ruleGroups: state.ruleGroups.filter(rg => rg !== ruleGroup), activeRuleGroupId: (_b = (_a = state.ruleGroups) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.id });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].setActiveRuleGroup, (state, { id }) => {
    return Object.assign(Object.assign({}, state), { activeRuleGroupId: id });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].addRule, (state, { ruleGroup }) => {
    ruleGroup.rules = [...ruleGroup.rules, new _models_rule__WEBPACK_IMPORTED_MODULE_3__["Rule"]()];
    return Object.assign(Object.assign({}, state), { ruleGroups: [
            ...state.ruleGroups,
        ] });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].deleteRule, (state, { rule, ruleGroup }) => {
    ruleGroup.rules = ruleGroup.rules.filter(r => r !== rule);
    return Object.assign(Object.assign({}, state), { ruleGroups: [
            ...state.ruleGroups,
        ] });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].addRuleAction, (state, { rule }) => {
    rule.actions = [...rule.actions, new _models_rule_action__WEBPACK_IMPORTED_MODULE_4__["RuleAction"]()];
    return Object.assign(Object.assign({}, state), { ruleGroups: [
            ...state.ruleGroups,
        ] });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].deleteRuleAction, (state, { action, rule }) => {
    rule.actions = rule.actions.filter(a => a !== action);
    return Object.assign(Object.assign({}, state), { ruleGroups: [
            ...state.ruleGroups,
        ] });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].updateSettings, (state, { data }) => {
    return Object.assign(Object.assign({}, state), { uiSettings: Object.assign(Object.assign({}, state.uiSettings), data) });
}), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].resetAllRuleEnableFlags, (state => {
    state.ruleGroups.forEach((rg) => {
        rg.rules.forEach(rule => rule.enabled = true);
    });
    return Object.assign({}, state);
})));
function reducer(state, action) {
    return _reducer(state, action);
}


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "DhCm":
/*!******************************************************!*\
  !*** ./$_lazy_route_resources lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "DhCm";

/***/ }),

/***/ "Gndo":
/*!*******************************!*\
  !*** ./src/app/util/utils.ts ***!
  \*******************************/
/*! exports provided: uuid, UniqNameGen, proxy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uuid", function() { return uuid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UniqNameGen", function() { return UniqNameGen; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "proxy", function() { return proxy; });
const baseStr = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
const uuid = () => {
    return baseStr.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};
function* UniqNameGen(prefix) {
    let index = 1;
    do {
        yield `${prefix} ${index}`;
        index++;
    } while (true);
}
const noop = () => { };
const proxy = (context, functionName, beforeFn = noop, afterFn = noop) => {
    let origFn = context[functionName];
    if (origFn) {
        origFn = origFn.bind(context);
        context[functionName] = (...args) => {
            beforeFn(...args);
            origFn(...args);
            afterFn(...args);
        };
    }
};


/***/ }),

/***/ "JSlr":
/*!***********************************************************************!*\
  !*** ./src/app/components/extension-info/extension-info.component.ts ***!
  \***********************************************************************/
/*! exports provided: ExtensionInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtensionInfoComponent", function() { return ExtensionInfoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class ExtensionInfoComponent {
}
ExtensionInfoComponent.ɵfac = function ExtensionInfoComponent_Factory(t) { return new (t || ExtensionInfoComponent)(); };
ExtensionInfoComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ExtensionInfoComponent, selectors: [["app-extension-info"]], decls: 43, vars: 0, consts: [[1, "full-width-height", "text-muted", "bg-light", "d-flex", "flex-column", "info-container"], [1, "text-muted", "fa-2x", "mt-5", "mb-5", "info", "text-center"], [1, "fa", "fa-hand-point-left"], [1, "d-flex", "justify-content-center", "flex-wrap"], [1, "card"], [1, "card-header", "text-center"], [1, "fas", "fa-h-square", "fa-10x", "text-primary"], [1, "card-body"], [1, "card-title"], [1, "card-text"], [1, "card-header", "text-center", "d-flex", "align-items-center", "justify-content-center"], [1, "p-image"], [1, "fa", "fa-ban", "fa-9x", "c-tomato"], [1, "fa", "fa-random", "fa-9x", "text-success", "redirect-request"], [1, "fa", "fa-clock", "fa-9x", "text-info"]], template: function ExtensionInfoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Create Rule Groups and Rules to Intercept Network Requests ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "h5", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Headers");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Add, Edit, Delete Request/Response Headers");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h5", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Query Params");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Add, Edit, Delete Query Params");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "h5", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Block Request");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "h5", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Redirect Requests");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](37, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "h5", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Throttle Response");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Delay response for static resources");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".info-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  width: 230px;\n  margin-left: 15px;\n  margin-right: 15px;\n}\n.info-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  height: 165px;\n}\n.info-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-text[_ngcontent-%COMP%] {\n  font-size: 0.85em;\n}\n.info-container[_ngcontent-%COMP%]   .p-image[_ngcontent-%COMP%] {\n  background-image: url(\"/assets/images/query-params.svg\");\n  background-repeat: no-repeat;\n  width: 125px;\n  height: 140px;\n  position: relative;\n  top: 8px;\n}\n.info-container[_ngcontent-%COMP%]   .redirect-request[_ngcontent-%COMP%] {\n  position: relative;\n  top: 10px;\n}\n.info-container[_ngcontent-%COMP%]   .c-tomato[_ngcontent-%COMP%] {\n  color: tomato;\n}\n.info-container[_ngcontent-%COMP%]   .info[_ngcontent-%COMP%] {\n  font-weight: 300;\n}"] });


/***/ }),

/***/ "Jzxw":
/*!***************************************!*\
  !*** ./src/app/models/ui-settings.ts ***!
  \***************************************/
/*! exports provided: UiSettings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UiSettings", function() { return UiSettings; });
class UiSettings {
    constructor(arg) {
        Object.assign(this, arg);
    }
}


/***/ }),

/***/ "K9il":
/*!**********************************!*\
  !*** ./src/app/store/actions.ts ***!
  \**********************************/
/*! exports provided: Actions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Actions", function() { return Actions; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const type = `[Request-Interceptor]`;
var Actions;
(function (Actions) {
    Actions.fetchDataSet = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} fetchDataSet`);
    Actions.fetchDataSetSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} fetchDataSetSuccess`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.fetchDataSetFailure = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} fetchDataSetFailure`);
    Actions.saveDataSet = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} saveDataSet`);
    Actions.saveDataSetSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} saveDataSetSuccess`);
    Actions.enableExtension = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} enableExtension`);
    Actions.disableExtension = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} disableExtension`);
    Actions.addRuleGroup = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} addRuleGroup`);
    Actions.deleteRuleGroup = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} deleteRuleGroup`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.setActiveRuleGroup = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} setActiveRuleGroup`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.addRule = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} addRule`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.deleteRule = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} deleteRule`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.addRuleAction = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} addRuleAction`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.deleteRuleAction = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} deleteRuleAction`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.hasUnsavedChanges = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} hasUnsavedChanges`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.onChange = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} onChange`);
    Actions.importRules = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} importRules`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.updateSettings = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} updateSettings`, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
    Actions.resetAllRuleEnableFlags = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])(`${type} resetAllRuleEnableFlags`);
})(Actions || (Actions = {}));


/***/ }),

/***/ "N2p+":
/*!*********************************************!*\
  !*** ./src/app/services/mock-background.ts ***!
  \*********************************************/
/*! exports provided: backgroundPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "backgroundPage", function() { return backgroundPage; });
const storage_key = '__request_interceptor_ls_key__';
const countMap = new Map();
const getDataSet = () => {
    return new Promise((resolve, reject) => {
        const config = JSON.parse(window.localStorage.getItem(storage_key)) || {};
        setTimeout(() => resolve(config), 500);
    });
};
const setDataSet = config => {
    return new Promise((resolve, reject) => {
        window.localStorage.setItem(storage_key, JSON.stringify(config));
        setTimeout(() => resolve(undefined), 500);
    });
};
const getCount = () => {
    return new Promise((resolve) => {
        resolve(countMap);
    });
};
const resetCount = () => {
    return new Promise(() => {
        countMap.clear();
    });
};
const backgroundPage = {
    getDataSet,
    setDataSet,
    getCount,
    resetCount,
};


/***/ }),

/***/ "QNtz":
/*!***********************************************************************************!*\
  !*** ./src/app/components/delete-confirm-modal/delete-confirm-modal.component.ts ***!
  \***********************************************************************************/
/*! exports provided: DeleteConfirmModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeleteConfirmModalComponent", function() { return DeleteConfirmModalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");


class DeleteConfirmModalComponent {
    constructor(modal) {
        this.modal = modal;
    }
    onCancel() {
        this.modal.close();
    }
    onOk() {
        this.modal.close('delete');
    }
}
DeleteConfirmModalComponent.ɵfac = function DeleteConfirmModalComponent_Factory(t) { return new (t || DeleteConfirmModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbActiveModal"])); };
DeleteConfirmModalComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DeleteConfirmModalComponent, selectors: [["ng-component"]], decls: 19, vars: 2, consts: [[1, "modal-header"], ["id", "modal-title", 1, "modal-title"], ["type", "button", "aria-describedby", "modal-title", 1, "close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "text-primary"], [1, "modal-footer"], ["type", "button", 1, "btn", "btn-secondary", "btn-sm", 3, "click"], ["type", "button", 1, "btn", "btn-danger", "btn-sm", 3, "click"]], template: function DeleteConfirmModalComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h4", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeleteConfirmModalComponent_Template_button_click_3_listener() { return ctx.modal.dismiss("Cross click"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "\u00D7");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Are you sure you want to delete ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, " group?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "All information associated to this rule group will be permanently deleted.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeleteConfirmModalComponent_Template_button_click_15_listener() { return ctx.onCancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeleteConfirmModalComponent_Template_button_click_17_listener() { return ctx.onOk(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Yes");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Delete ", ctx.title, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("\"", ctx.key, "\"");
    } }, styles: ["button.close[_ngcontent-%COMP%] {\n  outline: none;\n}\n\n.modal-footer[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\n  width: 90px;\n}"] });


/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./store/actions */ "K9il");
/* harmony import */ var _store_selectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./store/selectors */ "YqyA");
/* harmony import */ var _services_data_model_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/data-model.service */ "wfsL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _components_toggle_toggle_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/toggle/toggle.component */ "7FIb");
/* harmony import */ var _components_rule_groups_rule_groups_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/rule-groups/rule-groups.component */ "cP48");











function AppComponent_i_31_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "i", 28);
} }
function AppComponent_div_44_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AppComponent_ng_template_46_ul_0_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "li", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Auto Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "app-toggle", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_ng_template_46_ul_0_Template_app_toggle_change_5_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9); const uiSettings_r7 = restoredCtx.ngIf; const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r8.onSettingsChange(uiSettings_r7, { autoSave: $event }); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "li", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Show Rule Description ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "app-toggle", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_ng_template_46_ul_0_Template_app_toggle_change_10_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9); const uiSettings_r7 = restoredCtx.ngIf; const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r10.onSettingsChange(uiSettings_r7, { showRuleDescription: $event }); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "li", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, " Show Rule enable/disable ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "app-toggle", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_ng_template_46_ul_0_Template_app_toggle_change_15_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9); const uiSettings_r7 = restoredCtx.ngIf; const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); ctx_r11.onRuleEnableDisable($event); return ctx_r11.onSettingsChange(uiSettings_r7, { allowRuleEnableDisable: $event }); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const uiSettings_r7 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("onText", "Yes")("offText", "No")("value", uiSettings_r7.autoSave);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("onText", "Yes")("offText", "No")("value", uiSettings_r7.showRuleDescription);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("onText", "Yes")("offText", "No")("value", uiSettings_r7.allowRuleEnableDisable);
} }
function AppComponent_ng_template_46_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AppComponent_ng_template_46_ul_0_Template, 16, 9, "ul", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "async");
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 1, ctx_r3.uiSettings$));
} }
function AppComponent_ng_template_48_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](0, "Settings");
} }
class AppComponent {
    constructor(dataModalService, cdr, appRef, domSanitizer, store) {
        this.dataModalService = dataModalService;
        this.cdr = cdr;
        this.appRef = appRef;
        this.domSanitizer = domSanitizer;
        this.store = store;
        this.title = 'Request-Interceptor';
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵpublishDefaultGlobalUtils"])();
    }
    ngOnInit() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].fetchDataSet());
        this.isExtensionEnabled$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_2__["Selectors"].isExtensionEnabled);
        this.isLoading$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_2__["Selectors"].isLoading);
        this.hasUnsavedChanges$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_2__["Selectors"].hasUnsavedChanges);
        this.uiSettings$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_2__["Selectors"].getUiSettings);
        // this.store.subscribe((s) => console.warn(s));
        this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_2__["Selectors"].getRuleGroups)
            .subscribe((ruleGroups = []) => {
            URL.revokeObjectURL(this.blobURL);
            this.blobURL = URL.createObjectURL(new Blob([JSON.stringify(ruleGroups, undefined, '\t')], { type: 'application/json' }));
            this.downloadURL = this.domSanitizer.bypassSecurityTrustUrl(this.blobURL);
        });
    }
    save() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].saveDataSet());
    }
    toggleExtension(value) {
        if (value) {
            this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].enableExtension());
        }
        else {
            this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].disableExtension());
        }
    }
    onImport($event) {
        const file = $event.target.files[0];
        const fileReader = new FileReader();
        fileReader.onloadend = () => {
            let content;
            try {
                content = JSON.parse(fileReader.result);
            }
            catch (e) {
                console.warn('Imported file contents are not valid.');
            }
            $event.target.value = null;
            if (content) {
                this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].importRules({ data: content }));
            }
        };
        fileReader.readAsText(file);
    }
    onChange() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].onChange());
    }
    ngOnDestroy() {
        URL.revokeObjectURL(this.blobURL);
    }
    onSettingsChange(uiSettings, $event) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].updateSettings({ data: $event }));
    }
    onRuleEnableDisable($event) {
        if (!$event) {
            this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_1__["Actions"].resetAllRuleEnableFlags());
        }
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_data_model_service__WEBPACK_IMPORTED_MODULE_3__["DataModelService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"])); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 50, vars: 14, consts: [[1, "redirect", 3, "change"], [1, "navbar", "navbar-expand-lg", "navbar-dark", "bg-dark"], ["href", "#", 1, "navbar-brand"], [1, "ml-auto"], [1, "navbar-nav", "ml-auto", "ml-md-0"], [1, "mr-2"], ["content", "Settings"], ["popoverClass", "settings-popup", 1, "btn", "btn-primary", "btn-sm", 3, "ngbPopover", "popoverTitle", "autoClose"], [1, "fa", "fa-wrench"], ["content", "Download saved rules as json"], ["download", "request-interceptor-rules.json", "target", "_blank", 1, "btn", "btn-primary", "btn-sm", 3, "href"], [1, "fa", "fa-download"], ["content", "Import rules from json file"], [1, "btn", "btn-primary", "btn-sm", "position-relative"], [1, "fa", "fa-file-import"], ["type", "file", "accept", ".json", 1, "position-absolute", 3, "change"], ["content", "Save rules"], [1, "btn", "btn-primary", "btn-sm", 3, "click"], [1, "fa", "fa-save"], ["class", "fa fa-exclamation blink ml-1", 4, "ngIf"], ["placement", "bottom-end"], ["slot", "content"], [1, "large", 3, "value", "change"], [1, "redirect__main"], [1, "redirect__footer"], ["class", "overlay", 4, "ngIf"], ["popContent", ""], ["popTitle", ""], [1, "fa", "fa-exclamation", "blink", "ml-1"], [1, "overlay"], [1, "loader"], ["class", "list-group", 4, "ngIf"], [1, "list-group"], [1, "list-group-item", "d-flex"], [1, "d-flex", "flex-grow-1", "align-items-center"], [1, "d-flex", "justify-content-end"], [1, "medium", 3, "onText", "offText", "value", "change"], [1, "flex-grow-1", "d-flex", "justify-content-end"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_Template_div_change_0_listener() { return ctx.onChange(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "nav", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "a", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ul", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "li", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "sl-tooltip", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "li", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "sl-tooltip", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "Download");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "li", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "sl-tooltip", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Import");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_Template_input_change_24_listener($event) { return ctx.onImport($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "li", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "sl-tooltip", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_button_click_27_listener() { return ctx.save(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "i", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](31, AppComponent_i_31_Template, 1, 0, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](32, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "sl-tooltip", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, " Enable/disable extension. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](37, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, " Requires Save action for the changes to reflect. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "app-toggle", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function AppComponent_Template_app_toggle_change_39_listener($event) { return ctx.toggleExtension($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](40, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "app-rule-groups");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](43, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](44, AppComponent_div_44_Template, 2, 0, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](45, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](46, AppComponent_ng_template_46_Template, 2, 3, "ng-template", null, 26, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](48, AppComponent_ng_template_48_Template, 1, 0, "ng-template", null, 27, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](47);
        const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngbPopover", _r2)("popoverTitle", _r4)("autoClose", "outside");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx.downloadURL, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](32, 8, ctx.hasUnsavedChanges$));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](40, 10, ctx.isExtensionEnabled$));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](45, 12, ctx.isLoading$));
    } }, directives: [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbPopover"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _components_toggle_toggle_component__WEBPACK_IMPORTED_MODULE_8__["ToggleComponent"], _components_rule_groups_rule_groups_component__WEBPACK_IMPORTED_MODULE_9__["RuleGroupsComponent"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["AsyncPipe"]], styles: [".redirect[_ngcontent-%COMP%] {\n  width: 100vw;\n  height: 100vh;\n  display: flex;\n  flex-direction: column;\n}\n.redirect[_ngcontent-%COMP%]   nav.navbar[_ngcontent-%COMP%] {\n  height: 50px;\n}\n.redirect[_ngcontent-%COMP%]   nav.navbar[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\n  width: 100px;\n}\n.redirect[_ngcontent-%COMP%]   nav.navbar[_ngcontent-%COMP%]   input[type=file][_ngcontent-%COMP%] {\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  opacity: 0;\n  width: 100%;\n}\n.redirect__main[_ngcontent-%COMP%] {\n  height: calc(100vh - 50px);\n}\n.overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: rgba(0, 0, 0, 0.5);\n  z-index: 2;\n}\n.overlay[_ngcontent-%COMP%]   .loader[_ngcontent-%COMP%] {\n  width: 130px;\n  height: 130px;\n  top: 50%;\n  left: 50%;\n  transform: translate(-65px, -65px);\n  background-image: url(\"/assets/images/loader.gif\");\n  background-repeat: no-repeat;\n  position: relative;\n}\n.fa-exclamation[_ngcontent-%COMP%] {\n  color: gold;\n}\n.blink[_ngcontent-%COMP%] {\n  animation: blink 2s steps(2, start) infinite;\n}\n@keyframes blink {\n  to {\n    visibility: hidden;\n  }\n}"] });


/***/ }),

/***/ "T0lN":
/*!************************************!*\
  !*** ./src/app/models/data-set.ts ***!
  \************************************/
/*! exports provided: DataSet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataSet", function() { return DataSet; });
/* harmony import */ var _rule_group__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rule-group */ "7BWJ");
/* harmony import */ var _ui_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ui-settings */ "Jzxw");


class DataSet {
    static create(data = {}) {
        const instance = new DataSet();
        instance.uiSettings = new _ui_settings__WEBPACK_IMPORTED_MODULE_1__["UiSettings"](data.uiSettings);
        instance.ruleGroups = (data.ruleGroups || []).map(rg => _rule_group__WEBPACK_IMPORTED_MODULE_0__["RuleGroup"].create(rg));
        return instance;
    }
}


/***/ }),

/***/ "YqyA":
/*!************************************!*\
  !*** ./src/app/store/selectors.ts ***!
  \************************************/
/*! exports provided: Selectors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Selectors", function() { return Selectors; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

var Selectors;
(function (Selectors) {
    Selectors.getRequestInterceptorState = (state) => state.requestInterceptor;
    Selectors.getUiSettings = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRequestInterceptorState, (state) => state.uiSettings);
    Selectors.getRuleGroups = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRequestInterceptorState, (state) => state.ruleGroups);
    Selectors.isExtensionEnabled = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getUiSettings, (uiSettings) => uiSettings.isExtensionEnabled);
    Selectors.getActiveRuleGroupId = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRequestInterceptorState, (state) => state.activeRuleGroupId);
    Selectors.getActiveRuleGroup = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRuleGroups, Selectors.getActiveRuleGroupId, (ruleGroups = [], id) => {
        return ruleGroups.find(rg => rg.id === id);
    });
    Selectors.isLoading = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRequestInterceptorState, (state) => state.loading);
    Selectors.hasUnsavedChanges = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createSelector"])(Selectors.getRequestInterceptorState, (state) => state.hasUnsavedChanges);
})(Selectors || (Selectors = {}));


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-select/ng-select */ "ZOsW");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _components_toggle_toggle_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/toggle/toggle.component */ "7FIb");
/* harmony import */ var _components_rule_groups_rule_groups_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/rule-groups/rule-groups.component */ "cP48");
/* harmony import */ var _components_delete_confirm_modal_delete_confirm_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/delete-confirm-modal/delete-confirm-modal.component */ "QNtz");
/* harmony import */ var _components_edit_rule_group_edit_rule_group_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/edit-rule-group/edit-rule-group.component */ "ljOk");
/* harmony import */ var _components_extension_info_extension_info_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/extension-info/extension-info.component */ "JSlr");
/* harmony import */ var _store_reducer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./store/reducer */ "9s53");
/* harmony import */ var _store_effects__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./store/effects */ "gnIP");
/* harmony import */ var _directives_delay_render_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./directives/delay-render.directive */ "bCWc");
/* harmony import */ var _components_edit_rule_edit_rule_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/edit-rule/edit-rule.component */ "6oBl");
/* harmony import */ var _shoelace_style_shoelace_dist_components_tooltip_tooltip_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @shoelace-style/shoelace/dist/components/tooltip/tooltip.js */ "eVWx");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ "fXoL");




















_shoelace_style_shoelace_dist_components_tooltip_tooltip_js__WEBPACK_IMPORTED_MODULE_16__["default"];
class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormsModule"],
            _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_2__["NgSelectModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbPopoverModule"],
            _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["StoreModule"].forRoot({
                requestInterceptor: _store_reducer__WEBPACK_IMPORTED_MODULE_12__["reducer"]
            }, {
                runtimeChecks: {
                    strictStateImmutability: false,
                    strictActionImmutability: false,
                }
            }),
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["EffectsModule"].forRoot([_store_effects__WEBPACK_IMPORTED_MODULE_13__["Effects"]]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_17__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
        _components_toggle_toggle_component__WEBPACK_IMPORTED_MODULE_7__["ToggleComponent"],
        _components_rule_groups_rule_groups_component__WEBPACK_IMPORTED_MODULE_8__["RuleGroupsComponent"],
        _components_delete_confirm_modal_delete_confirm_modal_component__WEBPACK_IMPORTED_MODULE_9__["DeleteConfirmModalComponent"],
        _components_edit_rule_group_edit_rule_group_component__WEBPACK_IMPORTED_MODULE_10__["EditRuleGroupComponent"],
        _components_edit_rule_edit_rule_component__WEBPACK_IMPORTED_MODULE_15__["EditRuleComponent"],
        _components_extension_info_extension_info_component__WEBPACK_IMPORTED_MODULE_11__["ExtensionInfoComponent"],
        _directives_delay_render_directive__WEBPACK_IMPORTED_MODULE_14__["DelayRenderDirective"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormsModule"],
        _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_2__["NgSelectModule"],
        _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbPopoverModule"], _ngrx_store__WEBPACK_IMPORTED_MODULE_3__["StoreRootModule"], _ngrx_effects__WEBPACK_IMPORTED_MODULE_4__["EffectsRootModule"]] }); })();


/***/ }),

/***/ "bCWc":
/*!******************************************************!*\
  !*** ./src/app/directives/delay-render.directive.ts ***!
  \******************************************************/
/*! exports provided: DelayRenderDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelayRenderDirective", function() { return DelayRenderDirective; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class DelayRenderDirective {
    constructor(templateRef, vcRef, cdRef) {
        this.templateRef = templateRef;
        this.vcRef = vcRef;
        this.cdRef = cdRef;
        this.delayRender = 0;
    }
    ngOnInit() {
        if (this.delayRenderLoading) {
            this.vcRef.createEmbeddedView(this.delayRenderLoading);
        }
        this.timer = setTimeout(() => {
            this.vcRef.clear();
            this.vcRef.createEmbeddedView(this.templateRef);
            this.cdRef.detectChanges();
        }, this.delayRender);
    }
    ngOnDestroy() {
        clearTimeout(this.timer);
    }
}
DelayRenderDirective.ɵfac = function DelayRenderDirective_Factory(t) { return new (t || DelayRenderDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"])); };
DelayRenderDirective.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({ type: DelayRenderDirective, selectors: [["", "delayRender", ""]], inputs: { delayRender: "delayRender", delayRenderLoading: "delayRenderLoading" } });


/***/ }),

/***/ "cP48":
/*!*****************************************************************!*\
  !*** ./src/app/components/rule-groups/rule-groups.component.ts ***!
  \*****************************************************************/
/*! exports provided: RuleGroupsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleGroupsComponent", function() { return RuleGroupsComponent; });
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store/actions */ "K9il");
/* harmony import */ var _store_selectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../store/selectors */ "YqyA");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_data_model_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/data-model.service */ "wfsL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _edit_rule_group_edit_rule_group_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../edit-rule-group/edit-rule-group.component */ "ljOk");







const _c0 = function (a0) { return { "bg-light": a0 }; };
function RuleGroupsComponent_sl_tooltip_10_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "sl-tooltip", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "li", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function RuleGroupsComponent_sl_tooltip_10_Template_li_click_3_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r3); const rg_r1 = restoredCtx.$implicit; const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r2.selectRuleGroup(rg_r1.id); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rg_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", rg_r1.name + " - " + (rg_r1.description || ""), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](3, _c0, ctx_r0.activeRuleGroupId === rg_r1.id));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](rg_r1.name);
} }
class RuleGroupsComponent {
    constructor(dataModelService, cdr, store) {
        this.dataModelService = dataModelService;
        this.cdr = cdr;
        this.store = store;
    }
    ngOnInit() {
        this.ruleGroups$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_1__["Selectors"].getRuleGroups);
        this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_1__["Selectors"].getActiveRuleGroupId)
            .subscribe((id) => this.activeRuleGroupId = id);
    }
    selectRuleGroup(id) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].setActiveRuleGroup({ id }));
    }
    addNewRuleGroup() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_0__["Actions"].addRuleGroup());
    }
    trackByFn(index) {
        return index;
    }
}
RuleGroupsComponent.ɵfac = function RuleGroupsComponent_Factory(t) { return new (t || RuleGroupsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_data_model_service__WEBPACK_IMPORTED_MODULE_3__["DataModelService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"])); };
RuleGroupsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: RuleGroupsComponent, selectors: [["app-rule-groups"]], decls: 23, vars: 4, consts: [[1, "rule-groups", "full-width-height", "d-flex"], [1, "groups-list", "full-height", "overflow-auto"], [1, "list-group", "add-new-group-ul"], [1, "list-group-item", "border-right-0"], ["placement", "bottom", "content", "Add a new rule group"], [1, "btn", "btn-block", "btn-primary", 3, "click"], [1, "fa", "fa-plus"], [1, "groups-list-ul", "list-group", "overflow-auto"], ["placement", "top", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "contribute-ul", "list-group", "full-width"], [1, "d-flex"], ["href", "https://www.linkedin.com/in/vinay-kaparthi/", "title", "View my linkedin profile", "target", "_blank", 1, "flex-fill", "d-flex"], [1, "btn", "btn-light", "flex-fill"], [1, "fab", "fa-linkedin", "text-info", "fa-2x"], ["href", "https://paypal.me/VinayKaparthi/50USD", "target", "_blank", 1, "flex-fill", "d-flex"], ["content", "Buy me a coffee \u2764"], [1, "btn", "btn-light", "flex-fill", "border-right-0"], [1, "fa", "fa-mug-hot", "text-info", "fa-2x"], [1, "group-main"], ["placement", "top"], ["slot", "content"], [1, "list-group-item", "border-right-0", 3, "ngClass", "click"]], template: function RuleGroupsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "ul", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "li", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "sl-tooltip", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function RuleGroupsComponent_Template_button_click_5_listener() { return ctx.addNewRuleGroup(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "i", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "New Rule Group");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "ul", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, RuleGroupsComponent_sl_tooltip_10_Template, 6, 5, "sl-tooltip", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "ul", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "li", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "a", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "sl-tooltip", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](20, "i", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](22, "app-edit-rule-group");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](11, 2, ctx.ruleGroups$))("ngForTrackBy", ctx.trackByFn);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"], _edit_rule_group_edit_rule_group_component__WEBPACK_IMPORTED_MODULE_6__["EditRuleGroupComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgClass"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["AsyncPipe"]], styles: [".rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%] {\n  width: 225px;\n  position: relative;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: normal;\n  height: calc(100% - 110px);\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%]   .list-group-item[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n  height: 50px;\n  flex-shrink: 0;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%]   .list-group-item[_ngcontent-%COMP%]:not(:first-child) {\n  padding-right: 0;\n  cursor: pointer;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%]   .list-item-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding-right: 0;\n  outline: none;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%]   .list-item-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:focus {\n  box-shadow: none;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .groups-list-ul.list-group[_ngcontent-%COMP%]   .list-item-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   .fa.fa-trash[_ngcontent-%COMP%]:hover {\n  color: var(--danger);\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .contribute-ul[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0;\n  height: 55px;\n}\n.rule-groups[_ngcontent-%COMP%]   .groups-list[_ngcontent-%COMP%]   .contribute-ul[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  height: 55px;\n}\n.rule-groups[_ngcontent-%COMP%]   .group-main[_ngcontent-%COMP%] {\n  flex: 1;\n}"] });


/***/ }),

/***/ "dRsL":
/*!****************************************!*\
  !*** ./src/app/models/action-types.ts ***!
  \****************************************/
/*! exports provided: ActionType, ActionTypesEnum, ActionTypes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActionType", function() { return ActionType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActionTypesEnum", function() { return ActionTypesEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActionTypes", function() { return ActionTypes; });
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
class ActionType {
    constructor(key, label) {
        this.key = key;
        this.label = label;
    }
}
var ActionTypesEnum;
(function (ActionTypesEnum) {
    ActionTypesEnum["BLOCK_REQUEST"] = "block-request";
    ActionTypesEnum["ADD_REQUEST_HEADER"] = "add-request-header";
    ActionTypesEnum["MODIFY_REQUEST_HEADER"] = "modify-request-header";
    ActionTypesEnum["DELETE_REQUEST_HEADER"] = "delete-request-header";
    ActionTypesEnum["ADD_RESPONSE_HEADER"] = "add-response-header";
    ActionTypesEnum["MODIFY_RESPONSE_HEADER"] = "modify-response-header";
    ActionTypesEnum["DELETE_RESPONSE_HEADER"] = "delete-response-header";
    ActionTypesEnum["ADD_QUERY_PARAM"] = "add-query-param";
    ActionTypesEnum["MODIFY_QUERY_PARAM"] = "modify-query-param";
    ActionTypesEnum["DELETE_QUERY_PARAM"] = "delete-query-param";
    ActionTypesEnum["REDIRECT_TO"] = "redirect-to";
    ActionTypesEnum["THROTTLE"] = "throttle";
    ActionTypesEnum["SCRIPT"] = "script";
})(ActionTypesEnum || (ActionTypesEnum = {}));
class ActionTypes {
}
_a = ActionTypesEnum.BLOCK_REQUEST, _b = ActionTypesEnum.ADD_REQUEST_HEADER, _c = ActionTypesEnum.MODIFY_REQUEST_HEADER, _d = ActionTypesEnum.DELETE_REQUEST_HEADER, _e = ActionTypesEnum.ADD_RESPONSE_HEADER, _f = ActionTypesEnum.MODIFY_RESPONSE_HEADER, _g = ActionTypesEnum.DELETE_RESPONSE_HEADER, _h = ActionTypesEnum.ADD_QUERY_PARAM, _j = ActionTypesEnum.MODIFY_QUERY_PARAM, _k = ActionTypesEnum.DELETE_QUERY_PARAM, _l = ActionTypesEnum.REDIRECT_TO, _m = ActionTypesEnum.THROTTLE, _o = ActionTypesEnum.SCRIPT;
ActionTypes[_a] = new ActionType(ActionTypesEnum.BLOCK_REQUEST, 'Block');
ActionTypes[_b] = new ActionType(ActionTypesEnum.ADD_REQUEST_HEADER, 'Add Request Header');
ActionTypes[_c] = new ActionType(ActionTypesEnum.MODIFY_REQUEST_HEADER, 'Modify Request Header');
ActionTypes[_d] = new ActionType(ActionTypesEnum.DELETE_REQUEST_HEADER, 'Delete Request Header');
ActionTypes[_e] = new ActionType(ActionTypesEnum.ADD_RESPONSE_HEADER, 'Add Response Header');
ActionTypes[_f] = new ActionType(ActionTypesEnum.MODIFY_RESPONSE_HEADER, 'Modify Response Header');
ActionTypes[_g] = new ActionType(ActionTypesEnum.DELETE_RESPONSE_HEADER, 'Delete Response Header');
ActionTypes[_h] = new ActionType(ActionTypesEnum.ADD_QUERY_PARAM, 'Add Query Param');
ActionTypes[_j] = new ActionType(ActionTypesEnum.MODIFY_QUERY_PARAM, 'Modify Query Param');
ActionTypes[_k] = new ActionType(ActionTypesEnum.DELETE_QUERY_PARAM, 'Delete Query Param');
ActionTypes[_l] = new ActionType(ActionTypesEnum.REDIRECT_TO, 'Redirect To');
ActionTypes[_m] = new ActionType(ActionTypesEnum.THROTTLE, 'Throttle');
ActionTypes[_o] = new ActionType(ActionTypesEnum.SCRIPT, 'Script');


/***/ }),

/***/ "gnIP":
/*!**********************************!*\
  !*** ./src/app/store/effects.ts ***!
  \**********************************/
/*! exports provided: Effects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Effects", function() { return Effects; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "9YHx");
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./actions */ "K9il");
/* harmony import */ var _selectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./selectors */ "YqyA");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_data_model_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/data-model.service */ "wfsL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "l7P3");









class Effects {
    constructor(actions$, dataModelService, store) {
        this.actions$ = actions$;
        this.dataModelService = dataModelService;
        this.store = store;
        // @ts-ignore
        this.fetchDataSet$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["createEffect"])(() => {
            return this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["ofType"])(_actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].fetchDataSet), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])((_) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const data = yield this.dataModelService.fetchDataSet();
                return _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].fetchDataSetSuccess({ data });
            })));
        });
        // @ts-ignore
        this.saveDataSet$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["createEffect"])(() => {
            return this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["ofType"])(_actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].saveDataSet), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["withLatestFrom"])(this.store.select(_selectors__WEBPACK_IMPORTED_MODULE_4__["Selectors"].getRequestInterceptorState)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(([, data]) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield this.dataModelService.saveAll(data);
                return _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].fetchDataSet();
            })));
        });
        // @ts-ignore
        this.changes$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["createEffect"])(() => {
            return this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["ofType"])(_actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].updateSettings, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].onChange, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].enableExtension, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].disableExtension, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].addRuleGroup, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].deleteRuleGroup, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].addRule, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].deleteRule, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].addRuleAction, _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].deleteRuleAction), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["withLatestFrom"])(this.store.select(_selectors__WEBPACK_IMPORTED_MODULE_4__["Selectors"].getUiSettings)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(([_, uiSettings]) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (uiSettings.autoSave) {
                    return _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].saveDataSet();
                }
                return _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].hasUnsavedChanges({ flag: true });
            })));
        });
        // @ts-ignore
        this.importRules$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["createEffect"])(() => {
            return this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["ofType"])(_actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].importRules), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["withLatestFrom"])(this.store.select(_selectors__WEBPACK_IMPORTED_MODULE_4__["Selectors"].getRuleGroups)), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(([{ data: importedRuleGroups }, existingRuleGroups]) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield this.dataModelService.importRules(importedRuleGroups, existingRuleGroups);
                return _actions__WEBPACK_IMPORTED_MODULE_3__["Actions"].saveDataSet();
            })));
        });
    }
}
Effects.ɵfac = function Effects_Factory(t) { return new (t || Effects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_services_data_model_service__WEBPACK_IMPORTED_MODULE_6__["DataModelService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"])); };
Effects.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: Effects, factory: Effects.ɵfac });


/***/ }),

/***/ "ljOk":
/*!*************************************************************************!*\
  !*** ./src/app/components/edit-rule-group/edit-rule-group.component.ts ***!
  \*************************************************************************/
/*! exports provided: EditRuleGroupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRuleGroupComponent", function() { return EditRuleGroupComponent; });
/* harmony import */ var _delete_confirm_modal_delete_confirm_modal_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../delete-confirm-modal/delete-confirm-modal.component */ "QNtz");
/* harmony import */ var _store_selectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../store/selectors */ "YqyA");
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../store/actions */ "K9il");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _services_data_model_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/data-model.service */ "wfsL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ng-select/ng-select */ "ZOsW");
/* harmony import */ var _toggle_toggle_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../toggle/toggle.component */ "7FIb");
/* harmony import */ var _directives_delay_render_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../directives/delay-render.directive */ "bCWc");
/* harmony import */ var _edit_rule_edit_rule_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../edit-rule/edit-rule.component */ "6oBl");
/* harmony import */ var _extension_info_extension_info_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../extension-info/extension-info.component */ "JSlr");














function EditRuleGroupComponent_div_1_ng_container_39_ul_1_li_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "li", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "app-edit-rule", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rule_r10 = ctx.$implicit;
    const first_r11 = ctx.first;
    const uiSettings_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().ngIf;
    const ruleGroup_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("rule", rule_r10)("ruleGroup", ruleGroup_r5)("uiSettings", uiSettings_r8)("showInfo", first_r11);
} }
function EditRuleGroupComponent_div_1_ng_container_39_ul_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ul", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, EditRuleGroupComponent_div_1_ng_container_39_ul_1_li_1_Template, 2, 4, "li", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ruleGroup_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2).ngIf;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ruleGroup_r5.rules)("ngForTrackBy", ctx_r7.trackByRuleId);
} }
function EditRuleGroupComponent_div_1_ng_container_39_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, EditRuleGroupComponent_div_1_ng_container_39_ul_1_Template, 2, 2, "ul", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r6.uiSettings$));
} }
function EditRuleGroupComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "Group Info");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "sl-tooltip", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function EditRuleGroupComponent_div_1_Template_input_ngModelChange_8_listener($event) { const ruleGroup_r5 = ctx.ngIf; return ruleGroup_r5.name = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "sl-tooltip", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "input", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function EditRuleGroupComponent_div_1_Template_input_ngModelChange_10_listener($event) { const ruleGroup_r5 = ctx.ngIf; return ruleGroup_r5.description = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, " Filter Condition ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "sl-tooltip", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](15, "i", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "ng-select", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function EditRuleGroupComponent_div_1_Template_ng_select_ngModelChange_17_listener($event) { const ruleGroup_r5 = ctx.ngIf; return ruleGroup_r5.filter.key = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ng-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Page URL");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "ng-select", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function EditRuleGroupComponent_div_1_Template_ng_select_ngModelChange_21_listener($event) { const ruleGroup_r5 = ctx.ngIf; return ruleGroup_r5.filter.condition = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "ng-option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](23, "Starts With");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](24, "ng-option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Contains");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "input", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function EditRuleGroupComponent_div_1_Template_input_ngModelChange_27_listener($event) { const ruleGroup_r5 = ctx.ngIf; return ruleGroup_r5.filter.value = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "sl-tooltip", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "app-toggle", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("change", function EditRuleGroupComponent_div_1_Template_app_toggle_change_30_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r21); const ruleGroup_r5 = restoredCtx.ngIf; const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); ruleGroup_r5.enabled = $event; return ctx_r20.onRulePropertyChange(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "sl-tooltip", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](35, "button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function EditRuleGroupComponent_div_1_Template_button_click_35_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r21); const ruleGroup_r5 = restoredCtx.ngIf; const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r22.addRule(ruleGroup_r5); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](36, "i", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38, "New Rule");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](39, EditRuleGroupComponent_div_1_ng_container_39_Template, 3, 3, "ng-container", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](40, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "sl-tooltip", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function EditRuleGroupComponent_div_1_Template_button_click_42_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r21); const ruleGroup_r5 = restoredCtx.ngIf; const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r23.showDeleteModal(ruleGroup_r5); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](43, "i", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](45, "Delete");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ruleGroup_r5 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ruleGroup_r5.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ruleGroup_r5.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ruleGroup_r5.filter.key)("clearable", false)("searchable", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ruleGroup_r5.filter.condition)("clearable", false)("searchable", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ruleGroup_r5.filter.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ruleGroup_r5.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("delayRender", 10)("delayRenderLoading", _r3);
} }
function EditRuleGroupComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-extension-info");
} }
function EditRuleGroupComponent_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "i", 42);
} }
class EditRuleGroupComponent {
    constructor(modalService, dataModalService, cdr, store) {
        this.modalService = modalService;
        this.dataModalService = dataModalService;
        this.cdr = cdr;
        this.store = store;
    }
    ngOnInit() {
        this.ruleGroup$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_1__["Selectors"].getActiveRuleGroup);
        this.uiSettings$ = this.store.select(_store_selectors__WEBPACK_IMPORTED_MODULE_1__["Selectors"].getUiSettings);
    }
    showDeleteModal(ruleGroup) {
        const modalRef = this.modalService.open(_delete_confirm_modal_delete_confirm_modal_component__WEBPACK_IMPORTED_MODULE_0__["DeleteConfirmModalComponent"]);
        modalRef.componentInstance.title = 'RuleGroup';
        modalRef.componentInstance.key = ruleGroup.name;
        modalRef.result
            .then((result) => {
            if (result === 'delete') {
                this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_2__["Actions"].deleteRuleGroup({ ruleGroup }));
            }
            modalRef.close();
            this.detectChanges();
        });
        this.detectChanges();
    }
    addRule(ruleGroup) {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_2__["Actions"].addRule({ ruleGroup }));
    }
    trackByRuleId(index, rule) {
        return rule.id;
    }
    detectChanges() {
        this.cdr.detectChanges();
    }
    onRulePropertyChange() {
        this.store.dispatch(_store_actions__WEBPACK_IMPORTED_MODULE_2__["Actions"].onChange());
    }
}
EditRuleGroupComponent.ɵfac = function EditRuleGroupComponent_Factory(t) { return new (t || EditRuleGroupComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_data_model_service__WEBPACK_IMPORTED_MODULE_5__["DataModelService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"])); };
EditRuleGroupComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: EditRuleGroupComponent, selectors: [["app-edit-rule-group"]], decls: 7, vars: 4, consts: [[1, "full-width-height", "edit-form-container"], ["class", "card full-width-height", 4, "ngIf", "ngIfElse"], ["infoTmpl", ""], ["loadingTmpl", ""], [1, "card", "full-width-height"], [1, "card-header"], [1, "d-flex"], [1, "flex-grow-1", "group-details"], [1, "form-group", "d-flex", "align-items-center"], [1, "w-130"], ["content", "Group Name", "placement", "bottom"], ["placeholder", "Enter Group Name", 1, "form-control", "w-260", "border-right-0", 3, "ngModel", "ngModelChange"], ["content", "Group description", "placement", "bottom"], ["placeholder", "Enter Group Description (optional)", 1, "form-control", "col-4", 3, "ngModel", "ngModelChange"], ["content", "rules in this group will be checked only when this condition is met.", "placement", "right"], [1, "fa", "fa-info-circle", "ml-1"], [1, "w-130", "form-control", "border-right-0", "p-0"], [1, "custom-ng-select", 3, "ngModel", "clearable", "searchable", "ngModelChange"], ["value", "page-url"], ["value", "starts-with"], ["value", "contains"], [1, "p-0", "col-4"], ["placeholder", "eg: http://google.com (optional)", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "group-details-actions"], ["content", "enable/disable all rules in this rule group", "placement", "left"], [1, "medium", 3, "value", "change"], [1, "card-body", "d-flex", "p-0"], [1, "rules-list", "full-width-height", "overflow-auto"], [1, "d-flex", "flex-row-reverse", "add-new-rule-wrapper"], ["content", "Add a new rule to this rule group", "placement", "left"], [1, "btn", "btn-primary", "btn-sm", 3, "click"], [1, "fa", "fa-plus"], [4, "delayRender", "delayRenderLoading"], [1, "card-footer", "text-muted", "d-flex", "justify-content-end"], ["content", "delete this rule group", "placement", "top"], [1, "btn", "btn-danger", "btn-sm", "mr-2", 3, "click"], [1, "fa", "fa-trash"], ["class", "list-group overflow-auto", 4, "ngIf"], [1, "list-group", "overflow-auto"], ["class", "list-group-item", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "list-group-item"], [3, "rule", "ruleGroup", "uiSettings", "showInfo"], [1, "fa", "fa-spinner", "fa-spin", "fa-2x"]], template: function EditRuleGroupComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, EditRuleGroupComponent_div_1_Template, 46, 12, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, EditRuleGroupComponent_ng_template_3_Template, 1, 0, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, EditRuleGroupComponent_ng_template_5_Template, 1, 0, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, ctx.ruleGroup$))("ngIfElse", _r1);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["NgModel"], _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_9__["NgSelectComponent"], _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_9__["ɵr"], _toggle_toggle_component__WEBPACK_IMPORTED_MODULE_10__["ToggleComponent"], _directives_delay_render_directive__WEBPACK_IMPORTED_MODULE_11__["DelayRenderDirective"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgForOf"], _edit_rule_edit_rule_component__WEBPACK_IMPORTED_MODULE_12__["EditRuleComponent"], _extension_info_extension_info_component__WEBPACK_IMPORTED_MODULE_13__["ExtensionInfoComponent"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["AsyncPipe"]], styles: [".edit-form-container[_ngcontent-%COMP%] {\n  overflow-y: auto;\n}\n.edit-form-container[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   .card-body[_ngcontent-%COMP%] {\n  height: calc(100% - 165px);\n}\n.edit-form-container[_ngcontent-%COMP%]   .group-actions[_ngcontent-%COMP%] {\n  width: 100px;\n  text-align: right;\n}\n.edit-form-container[_ngcontent-%COMP%]   .group-details[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n}\n.group-details-actions[_ngcontent-%COMP%] {\n  position: relative;\n  left: 4px;\n}\n.rules-list[_ngcontent-%COMP%]   .list-group[_ngcontent-%COMP%]   .list-group-item[_ngcontent-%COMP%] {\n  font-weight: normal;\n  border: none;\n}\n.rules-list[_ngcontent-%COMP%]    > ul[_ngcontent-%COMP%] {\n  height: calc(100% - 50px);\n}\n.add-new-rule-wrapper[_ngcontent-%COMP%] {\n  height: 50px;\n  padding: 10px 20px;\n}\n.w-130[_ngcontent-%COMP%] {\n  width: 130px;\n}\n.w-50-important[_ngcontent-%COMP%] {\n  width: 50px !important;\n}\n.w-50[_ngcontent-%COMP%] {\n  width: 50px;\n}\n.w-130[_ngcontent-%COMP%] {\n  width: 130px;\n}\n.w-260[_ngcontent-%COMP%] {\n  width: 260px;\n}\n.f-s-20[_ngcontent-%COMP%] {\n  font-size: 20px;\n}\nselect.form-control[_ngcontent-%COMP%] {\n  width: 130px;\n}\n.form-control[_ngcontent-%COMP%]:focus {\n  box-shadow: none;\n}\n.form-control[_ngcontent-%COMP%], .form-group[_ngcontent-%COMP%]    > label[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n.fa-spinner[_ngcontent-%COMP%] {\n  margin-left: 50%;\n}"] });


/***/ }),

/***/ "shEE":
/*!********************************!*\
  !*** ./src/app/models/rule.ts ***!
  \********************************/
/*! exports provided: RuleCriteria, Rule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleCriteria", function() { return RuleCriteria; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Rule", function() { return Rule; });
/* harmony import */ var _rule_action__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rule-action */ "wsZ2");
/* harmony import */ var _util_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/utils */ "Gndo");


class RuleCriteria {
    constructor() {
        this.key = 'url';
        this.condition = 'starts-with';
    }
    static create(data = {}) {
        const instance = new RuleCriteria();
        instance.key = data.key;
        instance.condition = data.condition;
        instance.value = data.value;
        return instance;
    }
}
class Rule {
    constructor(id = Object(_util_utils__WEBPACK_IMPORTED_MODULE_1__["uuid"])()) {
        this.enabled = true;
        this.id = id;
        this.criteria = new RuleCriteria();
        this.actions = [
            new _rule_action__WEBPACK_IMPORTED_MODULE_0__["RuleAction"]()
        ];
    }
    static create(data = {}) {
        var _a;
        const instance = new Rule(data.id);
        instance.criteria = RuleCriteria.create(data.criteria);
        instance.actions = (data.actions || []).map(action => _rule_action__WEBPACK_IMPORTED_MODULE_0__["RuleAction"].create(action));
        instance.description = data.description;
        instance.enabled = (_a = data.enabled) !== null && _a !== void 0 ? _a : true;
        return instance;
    }
}


/***/ }),

/***/ "wfsL":
/*!************************************************!*\
  !*** ./src/app/services/data-model.service.ts ***!
  \************************************************/
/*! exports provided: DataModelService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataModelService", function() { return DataModelService; });
/* harmony import */ var _models_action_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../models/action-types */ "dRsL");
/* harmony import */ var _mock_background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mock-background */ "N2p+");
/* harmony import */ var _models_data_set__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/data-set */ "T0lN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let extension;
if (chrome && chrome.extension) {
    extension = chrome.extension.getBackgroundPage().extension;
}
else {
    extension = _mock_background__WEBPACK_IMPORTED_MODULE_1__["backgroundPage"];
}
class DataModelService {
    constructor() {
    }
    fetchDataSet() {
        return extension.getDataSet().then((response) => {
            console.log('--- read-data-set', response);
            return _models_data_set__WEBPACK_IMPORTED_MODULE_2__["DataSet"].create(response);
        });
    }
    getActions() {
        return [
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].ADD_REQUEST_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].MODIFY_REQUEST_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].DELETE_REQUEST_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].ADD_RESPONSE_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].MODIFY_RESPONSE_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].DELETE_RESPONSE_HEADER],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].ADD_QUERY_PARAM],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].MODIFY_QUERY_PARAM],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].DELETE_QUERY_PARAM],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].BLOCK_REQUEST],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].REDIRECT_TO],
            _models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypes"][_models_action_types__WEBPACK_IMPORTED_MODULE_0__["ActionTypesEnum"].THROTTLE]
        ];
    }
    saveAll(dataSet) {
        console.log('--save-dataset', dataSet);
        return extension.setDataSet(dataSet);
    }
    importRules(importedRuleGroups, existingRuleGroups) {
        const rgMap = new Map();
        const ruleMap = new Map();
        existingRuleGroups.forEach(rg => {
            rgMap.set(rg.id, rg);
            rg.rules.forEach((rule, index) => {
                ruleMap.set(rule.id, {
                    index,
                    parentGroup: rg,
                    rule
                });
            });
        });
        importedRuleGroups.forEach(rg => {
            if (!rgMap.has(rg.id)) {
                existingRuleGroups.push(rg);
            }
            else {
                const existingGroup = rgMap.get(rg.id);
                rg.rules.forEach(rule => {
                    const match = ruleMap.get(rule.id);
                    if (match) {
                        const matchIndex = match.index;
                        match.parentGroup.rules.splice(matchIndex, 1, rule);
                    }
                    else {
                        existingGroup.rules.push(rule);
                    }
                });
            }
        });
        return Promise.resolve();
    }
}
DataModelService.ɵfac = function DataModelService_Factory(t) { return new (t || DataModelService)(); };
DataModelService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: DataModelService, factory: DataModelService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "wsZ2":
/*!***************************************!*\
  !*** ./src/app/models/rule-action.ts ***!
  \***************************************/
/*! exports provided: RuleActionDetails, RuleAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleActionDetails", function() { return RuleActionDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleAction", function() { return RuleAction; });
class RuleActionDetails {
    static create(data = {}) {
        const instance = new RuleActionDetails();
        if (data.name) {
            instance.name = data.name;
        }
        if (data.value) {
            instance.value = data.value;
        }
        return instance;
    }
}
class RuleAction {
    static create(data = {}) {
        const instance = new RuleAction();
        instance.type = data.type;
        instance.details = RuleActionDetails.create(data.details);
        return instance;
    }
}


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ })

},[[0,"runtime","vendor"]]]);